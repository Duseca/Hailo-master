import 'package:get/get.dart';

class HealthController extends GetxController {
  RxList hConditions = [].obs;


  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
}