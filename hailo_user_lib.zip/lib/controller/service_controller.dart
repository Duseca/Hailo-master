import 'package:get/get.dart';

class ServiceController extends GetxController {
  RxList<Map> careServices = <Map>[].obs;
  RxList servIcons = [].obs;


  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
}