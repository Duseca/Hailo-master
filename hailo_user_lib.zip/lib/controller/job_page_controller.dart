import 'package:get/get.dart';

class JobPageController extends GetxController {
  String? uid = Get.parameters["uid"], tid = Get.parameters["tid"];
}