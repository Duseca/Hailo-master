import 'package:get/get.dart';


class ScheduleTabController extends GetxController {
  String? uid = Get.parameters["uid"], cid= Get.parameters["cid"];
}