import 'package:flutter/material.dart';

const Color kPrimaryColor = Color(0xff49DDC4);
const Color kSecondaryColor = Color(0xffFF7991);
const Color kWhiteColor = Color(0xffffffff);
const Color kBlackColor = Color(0xff000000);
const Color kLightGreyColor = Color(0xffC4C4C4);
