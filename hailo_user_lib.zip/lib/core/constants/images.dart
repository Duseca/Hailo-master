const Hdelete = 'assets/delete.png';
const Hcart = 'assets/cart_icon.png';
const Hhousekeep = 'assets/housekeeping_icon.png';
const Hbathing = 'assets/bath_icon.png';

const Avatar = 'assets/avatar.png';
