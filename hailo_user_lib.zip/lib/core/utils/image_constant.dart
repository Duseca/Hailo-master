class ImageConstant {
  static String imgVectorCyan300232X390 =
      'assets/images/img_vector_cyan_300_232X390.png';

  static String imgVector30X25 = 'assets/images/img_vector_30X25.svg';

  static String imgArrowleftWhiteA700 =
      'assets/images/img_arrowleft_white_A700.svg';

  static String imgCar = 'assets/images/img_car.svg';

  static String imgEllipse93 = 'assets/images/img_ellipse93.png';

  static String imgVectorRedA100 = 'assets/images/img_vector_red_A100.png';

  static String imgArrowdownCyan300 =
      'assets/images/img_arrowdown_cyan_300.svg';

  static String imgEllipse125 = 'assets/images/img_ellipse125.png';

  static String imgCar29X32 = 'assets/images/img_car_29X32.svg';

  static String imgVectorRedA10024X24 =
      'assets/images/img_vector_red_A100_24X24.svg';

  static String imgVectorGray403 = 'assets/images/img_vector_gray_403.svg';

  static String imgVector = 'assets/images/img_vector.svg';

  static String imgArrowleft = 'assets/images/img_arrowleft.svg';

  static String imgSignal10X15 = 'assets/images/img_signal_10X15.svg';

  static String imgUndrawdetails = 'assets/images/img_undrawdetails.svg';

  static String imgArrowdown = 'assets/images/img_arrowdown.svg';

  static String imgContrast = 'assets/images/img_contrast.svg';

  static String imgEllipse96 = 'assets/images/img_ellipse96.png';

  static String imgClose = 'assets/images/img_close.svg';

  static String imgArrowup = 'assets/images/img_arrowup.svg';

  static String imgVectorWhiteA70030X30 =
      'assets/images/img_vector_white_A700_30X30.svg';

  static String imgEllipse8 = 'assets/images/img_ellipse8.png';

  static String imgLocation18X15 = 'assets/images/img_location_18X15.svg';

  static String imgCar27X38 = 'assets/images/img_car_27X38.svg';

  static String imgLock = 'assets/images/img_lock.svg';

  static String imgVectorGray3004X44 =
      'assets/images/img_vector_gray_300_4X44.svg';

  static String imgEllipse5 = 'assets/images/img_ellipse5.png';

  static String imgEllipse129 = 'assets/images/img_ellipse129.png';

  static String imgEllipse7 = 'assets/images/img_ellipse7.png';

  static String imgShare = 'assets/images/img_share.svg';

  static String imgClock = 'assets/images/img_clock.svg';

  static String imgVectorCyan30020X20 =
      'assets/images/img_vector_cyan_300_20X20.svg';

  static String imgVideocamera = 'assets/images/img_videocamera.svg';

  static String imgVectorCyan30018X18 =
      'assets/images/img_vector_cyan_300_18X18.svg';

  static String imgVectorWhiteA70016X16 =
      'assets/images/img_vector_white_A700_16X16.svg';

  static String imgArrowrightCyan300 =
      'assets/images/img_arrowright_cyan_300.svg';

  static String imgEllipse127 = 'assets/images/img_ellipse127.png';

  static String imgArrowright = 'assets/images/img_arrowright.svg';

  static String imgVector190X159 = 'assets/images/img_vector_190X159.png';

  static String imgVideocamera17X22 = 'assets/images/img_videocamera_17X22.svg';

  static String imgArrowleftRedA100 =
      'assets/images/img_arrowleft_red_A100.svg';

  static String imgEllipse10 = 'assets/images/img_ellipse10.png';

  static String imgGroup6 = 'assets/images/img_group6.svg';

  static String imgFile18X18 = 'assets/images/img_file_18X18.svg';

  static String imgVector31X31 = 'assets/images/img_vector_31X31.svg';

  static String imgCar25X31 = 'assets/images/img_car_25X31.svg';

  static String imgEllipse3 = 'assets/images/img_ellipse3.png';

  static String imgVolume32X21 = 'assets/images/img_volume_32X21.svg';

  static String imgArrowrightGray403 =
      'assets/images/img_arrowright_gray_403.svg';

  static String imgSettings = 'assets/images/img_settings.svg';

  static String imgLocation34X27 = 'assets/images/img_location_34X27.svg';

  static String imgNotch = 'assets/images/img_notch.svg';

  static String imgVectorCyan3008X11 =
      'assets/images/img_vector_cyan_300_8X11.svg';

  static String imgBookmark = 'assets/images/img_bookmark.svg';

  static String imgVectorCyan302 = 'assets/images/img_vector_cyan_302.svg';

  static String imgFolder = 'assets/images/img_folder.svg';

  static String imgEllipse110 = 'assets/images/img_ellipse110.png';

  static String imgCart59X59 = 'assets/images/img_cart_59X59.svg';

  static String imgVectorGray300 = 'assets/images/img_vector_gray_300.svg';

  static String imgVector18X18 = 'assets/images/img_vector_18X18.svg';

  static String imgGroup31 = 'assets/images/img_group31.svg';

  static String imgSignal = 'assets/images/img_signal.svg';

  static String imgVectorCyan303 = 'assets/images/img_vector_cyan_303.svg';

  static String imgGroup31WhiteA700796X390 =
      'assets/images/img_group31_white_A700_796X390.svg';

  static String imgVectorCyan30029X27 =
      'assets/images/img_vector_cyan_300_29X27.svg';

  static String imgMap = 'assets/images/img_map.svg';

  static String imgRectangle33634X390 =
      'assets/images/img_rectangle336_34X390.png';

  static String imgSignal10X17 = 'assets/images/img_signal_10X17.svg';

  static String imgFile28X28 = 'assets/images/img_file_28X28.svg';

  static String imgArrowrightRedA100 =
      'assets/images/img_arrowright_red_A100.svg';

  static String imgNotification = 'assets/images/img_notification.svg';

  static String imgVectorWhiteA70018X16 =
      'assets/images/img_vector_white_A700_18X16.svg';

  static String imgGroup114 = 'assets/images/img_group114.svg';

  static String imgVectorBlack90017X17 =
      'assets/images/img_vector_black_900_17X17.svg';

  static String imgVectorBlack900 = 'assets/images/img_vector_black_900.svg';

  static String imgPlus = 'assets/images/img_plus.svg';

  static String imgHome26X26 = 'assets/images/img_home_26X26.svg';

  static String imgVolume = 'assets/images/img_volume.svg';

  static String imgSearch = 'assets/images/img_search.svg';

  static String imgVectorWhiteA700 = 'assets/images/img_vector_white_A700.svg';

  static String imgMail = 'assets/images/img_mail.svg';

  static String imgVectorCyan30013X16 =
      'assets/images/img_vector_cyan_300_13X16.svg';

  static String imgVectorCyan30031X31 =
      'assets/images/img_vector_cyan_300_31X31.png';

  static String imgMail26X23 = 'assets/images/img_mail_26X23.svg';

  static String imgGroup31WhiteA700 =
      'assets/images/img_group31_white_A700.svg';

  static String imgFile = 'assets/images/img_file.svg';

  static String imgVectorCyan300 = 'assets/images/img_vector_cyan_300.svg';

  static String imgLocation = 'assets/images/img_location.svg';

  static String imgCar16X23 = 'assets/images/img_car_16X23.svg';

  static String imgVectorWhiteA70047X47 =
      'assets/images/img_vector_white_A700_47X47.svg';

  static String imgCamera = 'assets/images/img_camera.svg';

  static String imgClose12X12 = 'assets/images/img_close_12X12.svg';

  static String imgBackground372X390 =
      'assets/images/img_background_372X390.png';

  static String imgStar = 'assets/images/img_star.svg';

  static String imgCheckmark = 'assets/images/img_checkmark.svg';

  static String imgEllipse6 = 'assets/images/img_ellipse6.png';

  static String imgArrowrightWhiteA700 =
      'assets/images/img_arrowright_white_A700.svg';

  static String imgVectorCyan30026X23 =
      'assets/images/img_vector_cyan_300_26X23.svg';

  static String imgVectorCyan30018X19 =
      'assets/images/img_vector_cyan_300_18X19.svg';

  static String imgGoogle = 'assets/images/img_google.svg';

  static String imgCart = 'assets/images/img_cart.svg';

  static String imgTicket = 'assets/images/img_ticket.svg';

  static String imgVectorGray900 = 'assets/images/img_vector_gray_900.svg';

  static String imgArrowrightBlack900 =
      'assets/images/img_arrowright_black_900.svg';

  static String imgRectangle336151X390 =
      'assets/images/img_rectangle336_151X390.png';

  static String imgVolume30X30 = 'assets/images/img_volume_30X30.svg';

  static String imgVectorWhiteA70056X56 =
      'assets/images/img_vector_white_A700_56X56.svg';

  static String imgRectangle336 = 'assets/images/img_rectangle336.png';

  static String imgTrash = 'assets/images/img_trash.svg';

  static String imgLocation25X26 = 'assets/images/img_location_25X26.svg';

  static String imgComputer = 'assets/images/img_computer.svg';

  static String imgGroup27 = 'assets/images/img_group27.png';

  static String imgClock17X17 = 'assets/images/img_clock_17X17.svg';

  static String imgMinimize = 'assets/images/img_minimize.svg';

  static String imgHome = 'assets/images/img_home.svg';

  static String imgEllipse133 = 'assets/images/img_ellipse133.png';

  static String imgBackground = 'assets/images/img_background.png';

  static String imgEllipse4 = 'assets/images/img_ellipse4.png';

  static String imgBrightness = 'assets/images/img_brightness.svg';

  static String imgFolder19X25 = 'assets/images/img_folder_19X25.svg';

  static String imgEllipse131 = 'assets/images/img_ellipse131.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
