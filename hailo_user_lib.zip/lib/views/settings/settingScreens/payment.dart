import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hailo/core/constants/colors.dart';

import '../../../../core/common.dart';

class Payment extends StatelessWidget {
  const Payment({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_new,
            color: kPrimaryColor,
          ),
          onPressed: Get.back,
        ),
        title: Text(
          'Payment Settings',
          style: fontBody(fontSize: 24, fontWeight: FontWeight.w500),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 48),
        child: Column(
          children: [
            const SizedBox(
              height: 120,
            ),
            TextFormField(
              keyboardType: TextInputType.number,
              style: fontBody(fontSize: 16, fontWeight: FontWeight.w400),
              decoration: InputDecoration(
                suffixIcon: Image.asset(
                  'assets/mastercard.png',
                  height: 21,
                  width: 33,
                ),
                hintText: '0000 0000 0000 0000',
                hintStyle: fontBody(
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                    fontColor: const Color(0xffB7B7B7)),
                labelText: "Card Number",
                labelStyle: fontBody(
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                    fontColor: const Color(0xffB7B7B7)),
                border:
                OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide:
                    const BorderSide(color: Color(0xffE7E7E7), width: 1)),
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide:
                    const BorderSide(color: Color(0xff000000), width: 2)),
              ),
            ),
            const SizedBox(height: 20),
            //L name
            TextFormField(
              keyboardType: TextInputType.number,
              style: fontBody(fontSize: 16, fontWeight: FontWeight.w400),
              decoration: InputDecoration(
                hintStyle: fontBody(
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                    fontColor: const Color(0xffB7B7B7)),
                hintText: '00/00',
                labelText: "Exp.Date",
                labelStyle: fontBody(
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                    fontColor: const Color(0xffB7B7B7)),
                border:
                OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide:
                    const BorderSide(color: Color(0xffE7E7E7), width: 1)),
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide:
                    const BorderSide(color: Color(0xff000000), width: 2)),
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            TextFormField(
              keyboardType: TextInputType.number,
              style: fontBody(fontSize: 16, fontWeight: FontWeight.w400),
              decoration: InputDecoration(
                hintStyle: fontBody(
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                    fontColor: const Color(0xffB7B7B7)),
                hintText: '000',
                labelText: "CVV Number",
                labelStyle: fontBody(
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                    fontColor: const Color(0xffB7B7B7)),
                border:
                OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide:
                    const BorderSide(color: Color(0xffE7E7E7), width: 1)),
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide:
                    const BorderSide(color: Color(0xff000000), width: 2)),
              ),
            ),
            const SizedBox(height: 22),
            //L name
            TextFormField(
              keyboardType: TextInputType.name,
              style: fontBody(fontSize: 16, fontWeight: FontWeight.w400),
              decoration: InputDecoration(
                hintStyle: fontBody(
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                    fontColor: const Color(0xffB7B7B7)),
                hintText: 'Name Surname',
                labelText: "Name on Card",
                labelStyle: fontBody(
                    fontSize: 16,
                    fontWeight: FontWeight.w400,
                    fontColor: const Color(0xffB7B7B7)),
                border:
                OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide:
                    const BorderSide(color: Color(0xffE7E7E7), width: 1)),
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide:
                    const BorderSide(color: Color(0xff000000), width: 2)),
              ),
            ),
            const SizedBox(
              height: 127,
            ),
            Container(
              height: 50,
              width: 194,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(9), color: kPrimaryColor),
              child: Center(
                  child: Text(
                    'Save',
                    style: fontBody(
                        fontSize: 18,
                        fontWeight: FontWeight.w500,
                        fontColor: kWhiteColor),
                  )),
            )
          ],
        ),
      ),
    );
  }
}
